# Synopsis

Demonstrate how to retrieve the changeset associated with a git commit to a Pipeline job.

