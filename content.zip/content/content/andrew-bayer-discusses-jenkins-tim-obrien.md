---
:layout: refresh
:refresh_to_post_id: "/blog/2011/10/17/andrew-bayer-discusses-jenkins-with-tim-obrien"
---
