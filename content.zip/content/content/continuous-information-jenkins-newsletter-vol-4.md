---
:layout: refresh
:refresh_to_post_id: "/blog/2013/05/17/continuous-information-jenkins-newsletter-vol-4"
---
