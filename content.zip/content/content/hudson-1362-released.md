---
:layout: refresh
:refresh_to_post_id: "/blog/2010/06/14/hudson-1-362-released"
---
