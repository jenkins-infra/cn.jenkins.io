---
:layout: refresh
:refresh_to_post_id: "/blog/2010/06/11/casual-fridays-directing-traffic-with-hudson"
---
