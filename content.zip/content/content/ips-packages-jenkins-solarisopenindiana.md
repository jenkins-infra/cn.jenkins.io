---
:layout: refresh
:refresh_to_post_id: "/blog/2011/09/20/ips-packages-of-jenkins-for-solaris-openindiana"
---
