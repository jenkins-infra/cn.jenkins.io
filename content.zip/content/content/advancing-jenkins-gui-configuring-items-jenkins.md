---
:layout: refresh
:refresh_to_post_id: "/blog/2015/07/15/advancing-the-jenkins-gui-configuring-items-in-jenkins"
---
