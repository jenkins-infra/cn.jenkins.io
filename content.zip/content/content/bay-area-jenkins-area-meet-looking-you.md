---
:layout: refresh
:refresh_to_post_id: "/blog/2015/07/25/bay-area-jenkins-area-meet-up-is-looking-for-you"
---
