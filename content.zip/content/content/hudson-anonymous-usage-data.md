---
:layout: refresh
:refresh_to_post_id: "/blog/2010/08/17/hudson-anonymous-usage-data"
---
