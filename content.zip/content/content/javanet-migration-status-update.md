---
:layout: refresh
:refresh_to_post_id: "/blog/2010/11/23/java-net-migration-status-update"
---
