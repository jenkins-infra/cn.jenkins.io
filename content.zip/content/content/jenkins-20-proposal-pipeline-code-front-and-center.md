---
:layout: refresh
:refresh_to_post_id: "/blog/2015/10/28/jenkins-2-0-proposal-pipeline-as-code-front-and-center"
---
