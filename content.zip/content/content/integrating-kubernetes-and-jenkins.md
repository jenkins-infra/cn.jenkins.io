---
:layout: refresh
:refresh_to_post_id: "/blog/2015/07/24/integrating-kubernetes-and-jenkins"
---
