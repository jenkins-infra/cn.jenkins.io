---
:layout: refresh
:refresh_to_post_id: "/blog/2014/04/11/jenkins-1-532-3-lts-is-released"
---
