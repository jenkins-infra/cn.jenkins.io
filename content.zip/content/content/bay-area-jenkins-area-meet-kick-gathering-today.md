---
:layout: refresh
:refresh_to_post_id: "/blog/2015/08/04/bay-area-jenkins-area-meet-up-kick-off-gathering-today"
---
