---
:layout: refresh
:refresh_to_post_id: "/blog/2015/04/06/good-bye-java6"
---
