---
:layout: refresh
:refresh_to_post_id: "/blog/2011/06/08/building-a-software-diamond-with-jenkins"
---
