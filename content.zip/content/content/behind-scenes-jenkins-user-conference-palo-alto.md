---
:layout: refresh
:refresh_to_post_id: "/blog/2013/09/11/behind-the-scenes-of-the-jenkins-user-conference-palo-alto"
---
