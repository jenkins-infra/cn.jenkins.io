---
:layout: refresh
:refresh_to_post_id: "/blog/2014/05/30/adopt-a-plugin"
---
