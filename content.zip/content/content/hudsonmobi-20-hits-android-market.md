---
:layout: refresh
:refresh_to_post_id: "/blog/2010/08/16/hudsonmobi-2-0-hits-the-android-market"
---
