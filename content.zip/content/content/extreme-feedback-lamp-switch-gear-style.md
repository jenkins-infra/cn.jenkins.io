---
:layout: refresh
:refresh_to_post_id: "/blog/2013/09/05/extreme-feedback-lamp-switch-gear-style"
---
