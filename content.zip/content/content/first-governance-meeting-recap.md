---
:layout: refresh
:refresh_to_post_id: "/blog/2011/02/05/first-governance-meeting-recap"
---
