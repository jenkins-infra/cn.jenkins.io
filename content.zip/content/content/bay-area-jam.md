---
:layout: refresh
:refresh_to_post_id: "/blog/2015/09/30/bay-area-jam"
---
