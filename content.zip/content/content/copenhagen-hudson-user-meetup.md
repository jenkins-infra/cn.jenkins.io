---
:layout: refresh
:refresh_to_post_id: "/blog/2010/09/01/copenhagen-hudson-user-meetup"
---
