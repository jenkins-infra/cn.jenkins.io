---
:layout: refresh
:refresh_to_post_id: "/blog/2010/10/21/hudson-user-meet-up-in-jerusalem"
---
