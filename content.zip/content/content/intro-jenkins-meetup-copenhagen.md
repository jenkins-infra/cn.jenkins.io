---
:layout: refresh
:refresh_to_post_id: "/blog/2012/06/22/intro-to-jenkins-meetup-in-copenhagen"
---
