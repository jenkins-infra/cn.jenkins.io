---
:layout: refresh
:refresh_to_post_id: "/blog/2012/01/04/building-jenkins-plugins-with-gradle"
---
