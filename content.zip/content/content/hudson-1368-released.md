---
:layout: refresh
:refresh_to_post_id: "/blog/2010/07/27/hudson-1-368-released"
---
