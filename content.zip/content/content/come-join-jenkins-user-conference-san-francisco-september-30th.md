---
:layout: refresh
:refresh_to_post_id: "/blog/2012/09/11/come-join-the-jenkins-user-conference-san-francisco-on-september-30th"
---
