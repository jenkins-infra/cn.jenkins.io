---
:layout: refresh
:refresh_to_post_id: "/blog/2011/11/04/a-dead-bug-is-a-good-bug"
---
