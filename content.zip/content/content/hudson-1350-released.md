---
:layout: refresh
:refresh_to_post_id: "/blog/2010/03/15/hudson-1-350-released"
---
