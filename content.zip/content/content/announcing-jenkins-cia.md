---
:layout: refresh
:refresh_to_post_id: "/blog/2012/03/26/announcing-the-jenkins-cia"
---
