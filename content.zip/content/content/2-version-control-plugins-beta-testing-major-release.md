---
:layout: refresh
:refresh_to_post_id: "/blog/2013/08/01/2-version-control-plugins-in-beta-testing-before-a-major-release"
---
