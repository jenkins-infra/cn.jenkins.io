---
:layout: refresh
:refresh_to_post_id: "/blog/2010/08/31/hudson-at-javazone-meetup-in-oslo"
---
