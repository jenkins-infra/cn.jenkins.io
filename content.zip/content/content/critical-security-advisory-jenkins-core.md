---
:layout: refresh
:refresh_to_post_id: "/blog/2012/03/06/critical-security-advisory-in-jenkins-core"
---
