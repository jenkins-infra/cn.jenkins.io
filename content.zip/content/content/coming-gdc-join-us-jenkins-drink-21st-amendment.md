---
:layout: refresh
:refresh_to_post_id: "/blog/2013/03/12/coming-to-gdc-join-us-for-a-jenkins-drink-up-at-21st-amendment"
---
