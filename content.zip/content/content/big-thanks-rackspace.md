---
:layout: refresh
:refresh_to_post_id: "/blog/2011/06/09/a-big-thanks-to-rackspace"
---
