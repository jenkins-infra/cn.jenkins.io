---
:layout: refresh
:refresh_to_post_id: "/blog/2010/02/08/breaking-hudson-1-345-released"
---
