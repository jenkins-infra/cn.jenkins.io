---
:layout: refresh
:refresh_to_post_id: "/blog/2012/04/13/continuous-information-vol-2"
---
