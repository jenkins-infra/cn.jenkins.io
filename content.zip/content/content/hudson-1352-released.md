---
:layout: refresh
:refresh_to_post_id: "/blog/2010/03/22/hudson-1-352-released"
---
