---
:layout: refresh
:refresh_to_post_id: "/blog/2010/09/22/javaone-day-two-in-pictures"
---
