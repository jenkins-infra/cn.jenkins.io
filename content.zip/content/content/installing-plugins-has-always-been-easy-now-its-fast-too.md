---
:layout: refresh
:refresh_to_post_id: "/blog/2011/01/08/installing-plugins-has-always-been-easy-now-its-fast-too"
---
