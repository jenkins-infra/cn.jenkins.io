---
:layout: refresh
:refresh_to_post_id: "/blog/2010/06/22/hudson-1-363-released"
---
