---
:layout: refresh
:refresh_to_post_id: "/blog/2010/04/01/announcing-the-hudson-2-0-roadmap"
---
