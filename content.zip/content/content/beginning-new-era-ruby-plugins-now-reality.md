---
:layout: refresh
:refresh_to_post_id: "/blog/2011/11/15/the-beginning-of-a-new-era-ruby-plugins-now-a-reality"
---
