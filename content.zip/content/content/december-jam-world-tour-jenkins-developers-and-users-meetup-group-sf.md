---
:layout: refresh
:refresh_to_post_id: "/blog/2015/12/18/december-jam-world-tour-jenkins-developers-and-users-meetup-group-sf"
---
