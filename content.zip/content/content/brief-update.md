---
:layout: refresh
:refresh_to_post_id: "/blog/2010/12/01/a-brief-update"
---
