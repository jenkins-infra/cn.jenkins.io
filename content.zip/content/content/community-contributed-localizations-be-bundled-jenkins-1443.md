---
:layout: refresh
:refresh_to_post_id: "/blog/2011/12/02/community-contributed-localizations-to-be-bundled-in-jenkins-1-443"
---
