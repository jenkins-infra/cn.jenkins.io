---
:layout: refresh
:refresh_to_post_id: "/blog/2010/09/17/javaone-taking-shape"
---
