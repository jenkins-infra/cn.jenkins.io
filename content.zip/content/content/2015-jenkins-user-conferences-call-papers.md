---
:layout: refresh
:refresh_to_post_id: "/blog/2015/01/27/2015-jenkins-user-conferences-call-for-papers"
---
