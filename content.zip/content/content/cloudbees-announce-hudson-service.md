---
:layout: refresh
:refresh_to_post_id: "/blog/2010/08/26/cloudbees-announce-hudson-as-a-service"
---
