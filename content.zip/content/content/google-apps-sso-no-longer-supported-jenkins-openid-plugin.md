---
:layout: refresh
:refresh_to_post_id: "/blog/2015/03/06/google-apps-sso-no-longer-supported-in-jenkins-openid-plugin"
---
