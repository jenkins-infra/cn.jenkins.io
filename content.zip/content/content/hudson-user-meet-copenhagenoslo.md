---
:layout: refresh
:refresh_to_post_id: "/blog/2010/08/29/hudson-user-meet-up-in-copenhagen-oslo"
---
