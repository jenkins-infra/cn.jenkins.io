---
:layout: refresh
:refresh_to_post_id: "/blog/2011/04/04/the-final-two-run-off-vote-for-the-new-jenkins-logo"
---
