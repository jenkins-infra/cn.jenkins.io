---
:layout: refresh
:refresh_to_post_id: "/blog/2011/12/28/adding-diagrams-to-wiki"
---
