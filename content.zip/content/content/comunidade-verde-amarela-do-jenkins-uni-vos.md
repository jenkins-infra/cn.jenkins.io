---
:layout: refresh
:refresh_to_post_id: "/blog/2012/11/18/comunidade-verde-amarela-do-jenkins-uni-vos"
---
