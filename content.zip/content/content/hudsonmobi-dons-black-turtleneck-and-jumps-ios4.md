---
:layout: refresh
:refresh_to_post_id: "/blog/2010/09/05/hudsonmobi-dons-a-black-turtleneck-and-jumps-to-ios4"
---
