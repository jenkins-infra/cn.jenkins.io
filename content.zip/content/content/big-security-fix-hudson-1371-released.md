---
:layout: refresh
:refresh_to_post_id: "/blog/2010/08/10/big-security-fix-hudson-1-371-released"
---
