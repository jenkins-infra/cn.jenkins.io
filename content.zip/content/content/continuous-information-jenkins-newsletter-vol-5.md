---
:layout: refresh
:refresh_to_post_id: "/blog/2013/09/16/continuous-information-jenkins-newsletter-vol-5"
---
