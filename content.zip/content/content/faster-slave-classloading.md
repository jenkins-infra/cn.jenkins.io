---
:layout: refresh
:refresh_to_post_id: "/blog/2013/07/24/faster-slave-classloading"
---
