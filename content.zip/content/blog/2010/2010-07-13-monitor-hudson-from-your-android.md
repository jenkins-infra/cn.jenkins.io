---
:layout: post
:title: Monitor Hudson from your Android
:nodeid: 228
:created: 1279029600
:tags:
- general
- just for fun
- releases
:author: rtyler
---
<img src="http://www.hudson-labs.org/sites/default/files/mood_widget-good.png" align="left" hspace="10"/> So you've got your fancy Android cell phone and you're thinking to yourself "besides feeling smugly superior to iPhone users, what can I do with this thing?" Perhaps you should be considering using it as a *phone* but if that's too boring, check out the new and improved ***[Hudson Mood widget for Android](http://wiki.hudson-ci.org/display/HUDSON/Hudson+Mood+widget+for+Android)***! The latest release brings support for multiple servers and fancier graphics.

If you're interested in installing the widget, search for "Hudson Mood" in the Android Market, and be sure to thank [Siarhei Dudzin](http://sdudzin.blogspot.com/) for creating the widget!

<center><img src="http://www.hudson-labs.org/sites/default/files/mood_widget-settings.png" /></center>
