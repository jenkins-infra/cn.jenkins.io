---
:layout: post
:title: Would you like to, OK
:nodeid: 176
:created: 1268569800
:tags:
- meta
:author: rtyler
---
As Matt Brown pointed out on the `dev@` list, Hudson made a cameo on [The Daily WTF](http://thedailywtf.com) in their post [Nobulation Fail](http://thedailywtf.com/Articles/Nobulation-Fail.aspx).

<center><img src="http://agentdero.cachefly.net/scratch/hudson_install_dailywtf.png"/></center>


Kohsuke went on to mention on the mailing list:

> Looks like this one is already fixed back in October last year.

