---
:layout: post
:title: Hudson / Sauce OnDemand webinar
:nodeid: 240
:created: 1282325892
:tags:
- general
- news
:author: kohsuke
---
On September 1st, I'll be <a href="http://saucelabs.com/about/webinars#webinar-hudson">presenting in a Sauce Labs webinar about Hudson and Sauce OnDemand</a>. The talk will discuss how Hudson can be used with Sauce OnDemand, naturally, but it'll also cover broader Hudson/Selenium integrations.

Please <a href="https://www1.gotomeeting.com/register/789261128">register to this free event</a>, and looking forward to seeing to you virtually.
