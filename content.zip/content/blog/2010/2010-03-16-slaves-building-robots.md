---
:layout: post
:title: Slaves building robots
:nodeid: 174
:created: 1268747100
:tags:
- meta
:author: rtyler
---
A few weeks ago we covered [building Android apps with Hudson](http://blog.hudson-ci.org/content/getting-started-building-android-apps-hudson) thanks to a very informative post by [Hugo Visser](http://blog.hudson-ci.org/users/hvisser), ever thought about building Android *itself* with Hudson? Sony Ericsson apparently has, Continuous Blog reader and Hudson user <a id="aptureLink_dcxEa1lrQd" href="http://www.linkedin.com/in/christopherorr">Christopher Orr</a> sent me this screen shot from his recently purchased [Sony Ericsson Xperia X10 mini](http://www.engadget.com/2010/02/14/sony-ericsson-outs-xperia-x10-mini-and-xperia-x10-mini-pro/), notice the "Kernel version" field.


<center><img src="http://agentdero.cachefly.net/continuousblog/x10-mini-hudson.png" alt="About Me on the X10 Mini"/></center>

<br clear="all"/>

----

If you've got screen shots or photos spotting Hudson out in the big blue room, drop me an email at `tyler` at `linux dot com`

----
