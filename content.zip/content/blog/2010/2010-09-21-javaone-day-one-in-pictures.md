---
:layout: post
:title: 'JavaOne: Day One in Pictures'
:nodeid: 257
:created: 1285074000
:tags:
- general
- javaone
:author: rtyler
---
In case you haven't been following the [frequently updated @hudsonci](http://twitter.com/hudsonci) Twitter stream. Here's a collection of photos I've taken thus far.

<center><object width="400" height="300"> <param name="flashvars" value="offsite=true&lang=en-us&page_show_url=%2Fphotos%2Fhudsonlabs%2Fsets%2F72157624996965000%2Fshow%2F&page_show_back_url=%2Fphotos%2Fhudsonlabs%2Fsets%2F72157624996965000%2F&set_id=72157624996965000&jump_to="></param> <param name="movie" value="http://www.flickr.com/apps/slideshow/show.swf?v=71649"></param> <param name="allowFullScreen" value="true"></param><embed type="application/x-shockwave-flash" src="http://www.flickr.com/apps/slideshow/show.swf?v=71649" allowFullScreen="true" flashvars="offsite=true&lang=en-us&page_show_url=%2Fphotos%2Fhudsonlabs%2Fsets%2F72157624996965000%2Fshow%2F&page_show_back_url=%2Fphotos%2Fhudsonlabs%2Fsets%2F72157624996965000%2F&set_id=72157624996965000&jump_to=" width="400" height="300"></embed></object></center>

