---
:layout: post
:title: Hudson User Meet-up in Copenhagen/Oslo
:nodeid: 243
:created: 1283141296
:tags:
- general
- meetup
:author: kohsuke
---
<p>I'll be in Copenhagen from 9/5-9/7 and in Oslo 9/8-9/9 to present in JavaZone. I'd like to take advantage of the opportunities and have user meet-up events in those cities. Depending on the number of participants, it could be just a drink in a bar, or a talk in a meeting room.</p>

<p>So if you are:</p>
<ol>
	<li>in those cities,</li>
	<li>available in the evening of 9/6, 9/8, or 9/9, and</li>
	<li>willing to attend such an event,</li>
</ol>
<p>... then please <a href="mailto:kohsuke@infradna.com">let me know.</a></p>
<p>Also, if you have an office in those cities and willing to provide a space for an event, that would be extra appreciated!</p>
