---
:layout: post
:title: Hudson with Selenium and Sauce On-Demand Videos
:nodeid: 229
:created: 1279725300
:tags:
- general
- interview
- meetup
- jenkinsci
:author: rtyler
---
A few weeks ago, Kohsuke stopped by the [San Francisco Selenium Meetup](http://meetup.com/seleniumsanfrancisco) hosted by [Sauce Labs](http://saucelabs.com) to talk about all things Selenium and Hudson related (with a bit of Sauce in there too).

The good folks over at Sauce Labs have gotten around to posting some of the videos taken with Kohsuke.

Instead of embed the videos, I wanted to directly **[link to the post](http://saucelabs.com/blog/index.php/2010/07/sfse-meetup-videos-hudson-with-selenium-sauce-ondemand/)** and make sure that you all went over to check out Sauce Labs, they're up to some interesting things over there.
