---
:layout: post
:title: Hudson Events Calendar
:nodeid: 251
:created: 1283626934
:tags:
- general
- meta
:author: rtyler
---
Just wanted to let everybody know that I've gone ahead and added a [Calendar](/calendar) for all the upcoming Hudson-related events.

Hopefully we'll be able to add more and more events for the rest of the year including seminars, more meetups and potentially a few drink-ups!

Worth mentioning that I've not yet tested the iCal feed so if you have troubles with it, let me know (via the comments).
