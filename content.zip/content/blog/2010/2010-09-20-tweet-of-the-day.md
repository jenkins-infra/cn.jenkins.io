---
:layout: post
:title: Tweet of the Day
:nodeid: 256
:created: 1285039529
:tags:
- general
- just for fun
:author: rtyler
---
Some of you may have been following all the photos posted to the [hudsonlabs Flickr account](http://www.flickr.com/photos/hudsonlabs/) from this year's JavaOne conference in San Francisco. 

[Alan O'Leary](http://twitter.com/a1o1) responded to this photo with one of the [funniest comments](http://twitter.com/a1o1/status/25032555850) of the day:



<center><a href="http://www.flickr.com/photos/hudsonlabs/5008009575/" title="This way to JavaOne by hudson.labs, on Flickr"><img src="http://farm5.static.flickr.com/4151/5008009575_52e7f18fdf.jpg" width="500" height="375" alt="This way to JavaOne" /></a><br clear="all"><strong><em>"Java and Oracle - 'In Opposite Directions'"</em></strong></center>
