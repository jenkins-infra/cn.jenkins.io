---
:layout: post
:title: Gee Thanks
:nodeid: 224
:created: 1278514800
:tags:
- general
- feedback
- just for fun
:author: rtyler
---
`Squee-D` had some nice things to say in the `#hudson` [IRC channel](http://www.hudson-labs.org/content/chat) yesterday that I thought I would share:

> Just to sing some praise again, make sure you all know how appreciated it is, we absolutely love hudson, and appreciate everyone who develops and maintains it.


Positive feedback (and negative really) is always appreciated; have you thanked your plugin maintainer today?
