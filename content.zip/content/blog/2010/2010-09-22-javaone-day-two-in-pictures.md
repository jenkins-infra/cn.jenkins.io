---
:layout: post
:title: 'JavaOne: Day Two in Pictures'
:nodeid: 260
:created: 1285150020
:tags:
- general
- javaone
:author: rtyler
---
On the off chance you've not seen some of the photos posted to the [@hudsonci Twitter stream](http://twitter.com/hudsonci), here's some of the photos from day two of JavaOne.


<center><object width="400" height="300"> <param name="flashvars" value="offsite=true&lang=en-us&page_show_url=%2Fphotos%2Fhudsonlabs%2Fsets%2F72157625004467040%2Fshow%2F&page_show_back_url=%2Fphotos%2Fhudsonlabs%2Fsets%2F72157625004467040%2F&set_id=72157625004467040&jump_to="></param> <param name="movie" value="http://www.flickr.com/apps/slideshow/show.swf?v=71649"></param> <param name="allowFullScreen" value="true"></param><embed type="application/x-shockwave-flash" src="http://www.flickr.com/apps/slideshow/show.swf?v=71649" allowFullScreen="true" flashvars="offsite=true&lang=en-us&page_show_url=%2Fphotos%2Fhudsonlabs%2Fsets%2F72157625004467040%2Fshow%2F&page_show_back_url=%2Fphotos%2Fhudsonlabs%2Fsets%2F72157625004467040%2F&set_id=72157625004467040&jump_to=" width="400" height="300"></embed></object></center>
<!--break-->
