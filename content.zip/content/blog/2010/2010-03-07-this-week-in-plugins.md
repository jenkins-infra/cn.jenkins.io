---
:layout: post
:title: This Week in Plugins
:nodeid: 182
:created: 1267991163
:tags:
- infrastructure
- feedback
:author: rtyler
---
A little late, but this past week we released **19** plugins including one new release, the [Libvirt Slaves](http://wiki.hudson-ci.org/display/HUDSON/Libvirt+Slaves+Plugin).


* **Feb 28th**
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/Accurev+Plugin">Accurev plugin</a> 0.6.10

* **Mar 1st**
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/Subversion+Release+Manager">Subversion Release Manager plugin</a> 1.1
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/Clover+Plugin">Clover plugin</a> 2.6.3
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/SCTMExecutor">SCTMExecutor</a> 1.5
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/Global+Build+Stats+Plugin">global-build-stats plugin</a> 0.1-alpha3

* **Mar 2nd**
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/ClearCase+UCM+Baseline+Plugin">ClearCase UCM Baseline Plug-in</a> 1.4
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/Accurev+Plugin">Accurev plugin</a> 0.6.11
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/JIRA+Plugin">JIRA plugin</a> 1.20


* **Mar 3rd**
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/NAnt+Plugin">NAnt Plugin</a> 1.4.1
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/Trac+Plugin">Edgewall Trac plugin</a> 1.10
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/NCover+Plugin">NCover plugin</a> 0.3
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/Nabaztag+Plugin">nabaztag</a> 1.7
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/Mozmill+Plugin">Mozmill Plugin</a> 1.3
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/Mantis+Plugin">Mantis plugin</a> 0.9
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/Harvest+Plugin">Harvest SCM</a> 0.3
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/Subversion+Plugin">Subversion Plug-in</a> 1.12

* **Mar 4th**
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/PerfPublisher+Plugin">Performance Publisher plugin</a> 7.96
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/Artifactory+Plugin">Artifactory Plugin</a> 1.0.7

* **Mar 5th**
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/Perforce+Plugin">Perforce Plugin</a> 1.0.23


* **Mar 6th**
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/SCTMExecutor">SCTMExecutor</a> 1.5.1

* **Mar 7th**
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/Libvirt+Slaves+Plugin">Libvirt Slaves plugin</a> 1.0
   * <a href="http://wiki.hudson-ci.org/display/HUDSON/Emma+Plugin">Emma plugin</a> 1.13
<!--break-->
