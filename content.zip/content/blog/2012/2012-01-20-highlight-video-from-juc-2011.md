---
:layout: post
:title: Highlight video from JUC 2011
:nodeid: 370
:created: 1327046400
:tags:
- general
- juc
:author: rtyler
---
A slick highlight video from the [Jenkins User Conference, 2011](/content/jenkins-user-conference) was posted recently which captures some great quotes from a number of the fantastic speakers who participated in the inaugural JUC.

I've embedded the video below, enjoy!

<center><iframe width="560" height="315" src="http://www.youtube.com/embed/_l9OgJc4_-w" frameborder="0" allowfullscreen></iframe></center>
