---
:layout: post
:title: Volunteers needed for JUC SF
:nodeid: 392
:created: 1346079600
:tags:
- general
- cia
- juc
:author: rtyler
---
<img src="http://agentdero.cachefly.net/continuousblog/images/Jenkins_SanFran_T-ShirtM.jpg" align="right"/>

Recently, Jenkins User Conference organizer Alyssa Tong sent out the following request:

> Jenkins User Conf SF is looking for volunteers to help us record the                                                                                          
sessions. Pls drop me an email if you're able to help.

We're trying to make sure we can capture video of as much of this year's conference as possible, but the only way we can do that is with your help!

If you'll be in town for JavaOne, or just live in the bay area, drop Alyssa an email at `atong@cloudbees.com`.
