---
:layout: post
:title: Ruby Plugins Hack Session 5/27/2011
:nodeid: 309
:created: 1306505812
:tags:
- development
- core
- ruby
- jruby
:author: cowboyd
---
After a one week hiatus, we returned to the weekly hack session on a mission light up the sky with fire!  

## Attendees

[Charles Lowell](http://twitter.com/cowboyd), Rasheed Abdul-Aziz, [Hiroshi Nakamura](http://twitter.com/nahi)

## Discussion/Accomplished

* How to manage the different ScriptingContainers inside the Jenkins
* renamed the experimental repo where we've been doing all of our development from fog.hpi to the more aptly name [https://github.com/cowboyd/jenkins-ruby-plugins-playground]
* started a separate gem for housing the support libraries for jenkins here [https://github.com/cowboyd/jenkins-plugins.rb]
* started with more formal definition of the plugin API there.

