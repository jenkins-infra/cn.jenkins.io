---
:layout: post
:title: 'Fundraising drive update: thank you everyone!'
:nodeid: 360
:created: 1324319410
:tags:
- general
- meta
- news
:author: kohsuke
---
<div style="float:right; margin:1em"><a href="http://www.flickr.com/photos/colinzhu/321306018/">
<img src="http://jenkins-ci.org/sites/default/files/gift.png">
</a></div>

Our <a href="/content/holiday-appeal-please-help-jenkins-pay-project-expense">earlier appeal</a> for donation was a drastic boost to <a href="https://wiki.jenkins-ci.org/display/JENKINS/Donation">our fund-raising drive</a>, (and looking at the twitter reactions, it feels like the Wikipedia parody we put on <a href="http://ci.jenkins-ci.org/">Jenkins on Jenkins</a> helped spread the words &mdash; I guess jokes do work!

And I'm happy to report that we've successfully raised over $12000 as of today. That's more than enough to pay off all the current balance and it should keep the project going for quite a while. I've assembled <a href="https://wiki.jenkins-ci.org/display/JENKINS/Donors">the donor list</a> in appreciation.

So once again, thanks everyone for their generous support!
