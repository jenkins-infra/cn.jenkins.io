---
:layout: post
:title: Jenkins Meetup Munich Videos
:nodeid: 346
:created: 1320674400
:tags:
- general
- meetup
- video
:author: rtyler
---
Better late than never right? Back in June, during his world tour, [Andrew Bayer](https://twitter.com/abayer) stopped by Munich to participate in a Jenkins Meetup along with Dr. Ullrich Hafner.

Andrew gave a talk titled "The State of Jenkins" ([slides](http://video.tngtech.com/veranstaltungen/2011/06-30Jenkins/The_State_of_Jenkins.pdf)) and Ullrich talked about "Static Code Analysis with Jenkins" ([slides](http://video.tngtech.com/veranstaltungen/2011/06-30Jenkins/Static_Code_Analysis_With_Jenkins.pdf))

You can view the videos on [this page](http://video.tngtech.com/veranstaltungen/2011/06-30Jenkins/#) hosted by [TNG](http://www.tngtech.com).

*Thanks to Stefan Wolf for the heads up!*
