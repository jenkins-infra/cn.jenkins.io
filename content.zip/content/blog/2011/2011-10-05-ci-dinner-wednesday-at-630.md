---
:layout: post
:title: CI Dinner Wednesday at 6:30
:nodeid: 341
:created: 1317825000
:tags:
- general
- just for fun
- meetup
- javaone
:author: rtyler
---
<img src="http://s3-media2.ak.yelpcdn.com/bphoto/fFGPBtsutYpn3A155Sf75Q/l.jpg" align="right" width="200" alt="Photo from inside Cafe Chaat"/>Apologies for the late notice, I think most of us have been pre-occupied with [that fantastic Jenkins User Conference](http://www.cloudbees.com/jenkins-user-conference-2011.cb). While there are plenty of folks in town for JavaOne, I wanted to host a meetup/dinner at **[Cafe Chaat](http://www.yelp.com/biz/cafe-chaat-san-francisco-4)** here in San Francisco.

If you're coming from JavaOne directly, use [these directions](http://g.co/maps/dwwzj)

If you're coming from Oracle OpenWorld, use [these directions](http://g.co/maps/2db79)

[Kohsuke](https://twitter.com/kohsukekawa) will be in attendance as will some other Jenkins User Conference speakers, so if you still have left-over questions, I'm sure you can get them answered before the last of the [Mango Lassi](https://secure.wikimedia.org/wikipedia/en/wiki/Lassi#Mango_lassi) is finished!

Look forward to seeing you there!

<!--break-->
