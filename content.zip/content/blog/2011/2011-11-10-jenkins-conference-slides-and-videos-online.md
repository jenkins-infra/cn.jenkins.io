---
:layout: post
:title: Jenkins Conference Slides and Videos Online
:nodeid: 351
:created: 1320944891
:tags:
- general
- juc
- video
:author: rtyler
---
<img src="/sites/default/files/images/headshot.png" align="right"/>It is just turning into a video heavy week isn't it? First the [videos from the Munich Meetup](/content/jenkins-meetup-munich-videos) were made available, and now the videos from the *first* ever [Jenkins User Conference](/content/jenkins-user-conference).

The full list of slides and videos can be found **[on this page](https://www.cloudbees.com/jenkins-user-conference-2011-session-abstracts.cb)**, hosted by [CloudBees](https://www.cloudbees.com/) who  did a phenomenal job helping to organize and host the conference.


I want to thank everybody else involved once again, the fantastic speakers, the enthusiastic attendees and of course the sponsors for making it possible (CloudBees, Red Hat, LifeRay, New Relic, Sauce Labs, Chariot Solutions and eXo).
