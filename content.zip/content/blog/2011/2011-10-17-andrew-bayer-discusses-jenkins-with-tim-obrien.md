---
:layout: post
:title: Andrew Bayer discusses Jenkins with Tim O'Brien
:nodeid: 342
:created: 1318860000
:tags:
- general
- interview
- javaone
:author: rtyler
---
Recently, Jenkins Interim Governance Board member and core contributor, [Andrew Bayer](https://twitter.com/abayer) sat down with [Tim O'Brien](https://twitter.com/tobrian) to discuss the Jenkins project.

You can watch the video [on YouTube](http://www.youtube.com/watch?v=0p815FUCK_g) or via the embed below.

<iframe width="560" height="315" src="http://www.youtube.com/embed/0p815FUCK_g" frameborder="0" allowfullscreen></iframe>
