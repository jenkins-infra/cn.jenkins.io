---
:layout: post
:title: San Francisco Jenkins Meetup - Wednesday, April 13th
:nodeid: 297
:created: 1301673600
:tags:
- general
- meetup
- news
- jenkinsci
:author: abayer
---
<img src="http://agentdero.cachefly.net/continuousblog/images/ey_logo.png" alt="Engine Yard!" align="right"/>We're happy to announce that there'll be a Jenkins meetup in San Francisco on Wed., Apr 13th, generously hosted by [Engine Yard](http://www.engineyard.com/). The meetup will start at 6:30 - you can find more information [here](http://www.meetup.com/jenkinsmeetup/events/17090726/). [Dr Nic Williams of Engine Yard](http://twitter.com/drnic) will talk about their use of Jenkins with Ruby, and Kohsuke will give an update on the JRuby plugin development work he and [cowboyd](http://twitter.com/cowboyd) have been working on. If you're interesting in giving a short talk on your usage of Jenkins, plugin work, or whatever, there should be time for an open mic. Hope to see you there!
