---
:layout: post
:title: Office hour on form handling in Jenkins
:nodeid: 626
:created: 1442716589
:tags:
- general
- office hours
:author: daniel-beck
---
**Update: This week's office hour has been canceled.**

[This Wednesday, Sep 23, at 11 am PDT](http://www.timeanddate.com/worldclock/fixedtime.html?msg=Jenkins+Office+Hours&iso=20150923T11&p1=283&ah=1) I will host another office hour on [Stapler](http://stapler.kohsuke.org/), the web framework used in Jenkins. This time, I'll show you how structured form submission in Jenkins works, and how Stapler can help you with it.

As usual, the office hour will use Hangout on Air, and a limited number of people will be able to join and participate. The others will be able to watch the office hour live on YouTube. [Links to participate and watch will be posted before the event on the Office Hours wiki page](https://wiki.jenkins-ci.org/display/JENKINS/Office+Hours).

**Update: This week's office hour has been canceled.**
