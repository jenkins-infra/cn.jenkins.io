---
:layout: post
:title: JIRA migration this weekend
:nodeid: 541
:created: 1429888108
:tags:
- infrastructure
- news
:author: kohsuke
---
In continuing <a href="http://jenkins-ci.org/content/confluence-migration-weekend">my infra upgrade work</a>, this weekend I'll be migrating JIRA to another server.

This will make upgrade more manageable and testable. The service will be disrupted for a few hours. Check out our <a href="https://twitter.com/jenkinsci/">@jenkinsci on Twitter</a> for up-to-the-minute status.

Once the migration is done, the next step is to upgrade them.
